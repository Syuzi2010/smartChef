import java.util.*;
public class Main {
    public static void main(String[] args) {




                // Sample matrix with dish names and their required ingredients
                List<List<String>> dishesMatrix = new ArrayList<>();
                dishesMatrix.add(Arrays.asList("Pasta", "tomato", "onion", "garlic", "basil"));
                dishesMatrix.add(Arrays.asList("Salad", "lettuce", "tomato", "cucumber", "olive oil"));
                dishesMatrix.add(Arrays.asList("Pizza", "flour", "tomato", "cheese", "olive oil"));

                // Initialize Scanner for user input
                Scanner scanner = new Scanner(System.in);

                // Prompt user to input ingredients
                System.out.println("Enter the ingredients you have (separated by commas):");
                String input = scanner.nextLine();

                // Split the input into a list of ingredients
                List<String> userIngredients = Arrays.asList(input.split("\\s*,\\s*"));

                // Find matching dishes
                List<String> matchingDishes = findDishes(dishesMatrix, userIngredients);

                // Print the result
                if (!matchingDishes.isEmpty()) {
                    System.out.println("Dishes you can make: " + matchingDishes);
                } else {
                    System.out.println("No dishes can be made with the given ingredients.");
                }

                scanner.close();
            }

            public static List<String> findDishes(List<List<String>> dishesMatrix, List<String> userIngredients) {
                List<String> matchingDishes = new ArrayList<>();

                for (List<String> dish : dishesMatrix) {
                    String dishName = dish.get(0);
                    List<String> requiredIngredients = dish.subList(1, dish.size());

                    // Check if the user has all the required ingredients for the dish
                    if (userIngredients.containsAll(requiredIngredients)) {
                        matchingDishes.add(dishName);
                    }
                }

                return matchingDishes;
            }
        }
